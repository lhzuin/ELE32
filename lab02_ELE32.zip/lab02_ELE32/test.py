import numpy as np
import matplotlib.pyplot as plt

x = np.linspace(-10, 10, 1000)  # Generate 1000 x values between -10 and 10
y = (1 - x) / x                # Calculate the corresponding y values

plt.figure()
plt.plot(x, y)
plt.title('Graph of (1-x)/x')
plt.xlabel('x')
plt.ylabel('y')
plt.axhline(0, color='black', linewidth=0.5)
plt.axvline(0, color='black', linewidth=0.5)
plt.grid(True)
plt.show()