import numpy as np
import scipy.special as sp
from sympy import div, symbols, Poly, lcm

def cyclpoly(n, k):
    x = symbols('x')
    idx = np.arange(1, n)
    alpha = np.array([np.mod(i * k, n) for i in idx])
    D = sp.binom(n, alpha)
    D[D % 2 == 0] = 0
    D[D % 2 == 1] = 1
    D = D.astype(int)
    generator_polys = []
    
    for i in range(2 ** (n - 1)):
        binary = np.array(list(format(i, '0' + str(n - 1) + 'b')), dtype=int)
        if np.array_equal(binary & D, D):
            g_x = 1 + sum([b * x ** (n - 1 - j) for j, b in enumerate(binary)])
            generator_polys.append(g_x)
            
    return generator_polys

def best_code(n, k):
    # gero polinomios geradores
    generator_polynomials = cyclpoly(n, k)
    for poly in generator_polynomials:
        print(poly)
    #print(generator_polynomials)

    # utilizando a simetria, podemos escolher qualquer elemento do codigo e buscar pela distância mínima



best_code(7,3)